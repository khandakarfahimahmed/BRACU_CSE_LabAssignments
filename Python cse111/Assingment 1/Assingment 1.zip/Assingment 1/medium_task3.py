a = input ("Enter a number: ")
y=0
try:
    x = int(a)
except:
    print("Invalid input! Try again(Avoid letters)")
    exit()
for i in range(1,x):
    if x%i==0:
        y=y+i
if y==x:
    print("Perfect Number")
else:
    print("Not Perfect")
