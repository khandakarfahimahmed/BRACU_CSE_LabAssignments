n = input ("Enter a number: ")
a=0
b=1
print(a,end=" ")
print(b,end=" ")
try:
    x = int(n)
except:
    print("Invalid input! Try again(Avoid letters)")
    exit()
for i in range(0,x,):
    i=a+b
    a=b
    b=i
    print(i,end=" ")
