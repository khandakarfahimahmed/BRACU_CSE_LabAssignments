c=0
for i in range(1,31,1):
    if i%3==0 or i%5==0:
        print(i)
        c+=1
print("count:",c)
