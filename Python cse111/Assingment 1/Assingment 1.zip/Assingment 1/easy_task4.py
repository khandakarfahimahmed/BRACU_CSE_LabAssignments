a=input("Enter a number :")
try:
    x = int(a)
except:
    print("Invalid input! Try again(Avoid letters)")
    exit()
if x<=1:
    print("Not a prime number")
else:
    for i in range(2,x):
        if x==1:
            print("Not a prime number")
        elif x%i==0:
            print("Not a prime number")
            break
    else:
        print("prime number")
