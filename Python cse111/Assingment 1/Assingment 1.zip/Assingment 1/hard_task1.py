num= int(input("Enter quantity of numbers :"))
a=[]
for z in range(0,num,+1):
    p = int(input("Enter numbers :"))
    a.append(p)
uniq=[]
c=""
count=0
for i in a:
    if i not in uniq:
        uniq.append(i)
for j in range(0,5,+1):
    b=str(uniq[j])
    c=c+b
c=int(c)
while c>0:
    c=c//10
    count+=1
print(count,".",sep="")
