n = int(input("Enter number :"))
binNum= bin(n)
#print(binNum)
count = 0
binString= str(binNum)
strSize=len(binString)
i = 0
while(i<strSize):
	if binString[i] == '1':
		count+=1
	i+=1
#print(count)
num = 0
while count>0:
	num = (num*10) +1
	count-=1
#print(num)
strNum = str(num)
decNum=int(strNum,2)
print(decNum)
