a= []
q=int(input("Enter quantity of numbers :"))
for n in range(0,q,+1):
    x=int(input("Enter numbers :"))
    a.append(x)
for i in range(q-1,-1,-1):
    print(a[i],end="")
