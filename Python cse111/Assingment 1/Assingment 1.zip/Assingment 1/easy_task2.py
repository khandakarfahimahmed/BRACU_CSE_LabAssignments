q=3
a=[]
max=0
for i in range(0,q,+1):
    x=int(input("Enter digits :"))
    a.append(x)
if a[0]>a[1]:
    if a[0]<a[2]:
        max = a[2]
    else:
        max = a[0]
elif a[1]<a[2]:
    max = a[2]
else:
    max = a[1]
print(max)
