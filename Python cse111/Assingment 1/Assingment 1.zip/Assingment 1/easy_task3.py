a = input ("Enter marks: ")
try:
    x = int(a)
except:
    print("Invalid input! Try again(Avoid letters)")
    exit()
if x>=90:
    print("A")
elif x<50:
    print("F")
elif x<=51:
    print("D-")
elif x<=54:
    print("D")
elif x<=56:
    print("D+")
elif x<=59:
    print("C-")
elif x<=64:
    print("C")
elif x<=69:
    print("C+")
elif x<=74:
    print("B-")
elif x<=79:
    print("B")
elif x<=84:
    print("B+")
else:
    print("A-")
