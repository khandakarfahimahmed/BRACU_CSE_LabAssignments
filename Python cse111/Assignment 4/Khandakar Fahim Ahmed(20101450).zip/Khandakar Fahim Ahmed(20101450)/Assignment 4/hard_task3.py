s1=(input()).split(" ")
l1=list(map(int,s1))
s2=(input()).split(" ")
l2=list(map(int,s2))
n=l1[1]
c=0
for i in l2:
    if (i+n)<=5:
        c+=1
a=c//3
print(a)
