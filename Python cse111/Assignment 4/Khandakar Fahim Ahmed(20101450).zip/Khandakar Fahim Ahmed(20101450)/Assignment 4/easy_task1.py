
a=[]
for i in range(0,10):
    l = int(input("Enter input: "))
    a.append(l)
a.reverse()
for b in a:
    print(b,end=" ")
