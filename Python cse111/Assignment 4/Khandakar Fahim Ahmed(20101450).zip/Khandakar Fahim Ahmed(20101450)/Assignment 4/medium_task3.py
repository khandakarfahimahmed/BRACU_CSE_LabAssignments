a = (input()).split(" ")
b = (input()).split(" ")
l1 = list(map(int,a))
l2 = list(map(int,b))
l3 = []
for i in l1:
    for j in l2:
        x = i*j
        l3.append(x)
print(l3)
