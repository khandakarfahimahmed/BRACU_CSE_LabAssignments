a=[]
b = []

while True:
    l = input("Enter numgbers: ")
    if l=="STOP":
        break

    l = int(l)
    a.append(l)


for i in a:
    if i not in b:
        x = str(i)
        y = str(a.count(i))
        print(x+"-"+y+" times")
        b.append(i)
