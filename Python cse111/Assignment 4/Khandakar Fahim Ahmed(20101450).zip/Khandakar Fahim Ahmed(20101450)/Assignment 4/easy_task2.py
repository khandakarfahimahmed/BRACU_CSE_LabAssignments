
a = input("Enter digits by separating comma(,): ")
a = a.split(",")
b = input("Enter digits by separating comma(,): ")
b = b.split(",")
#lb = len(b)
la = len(a)
#print(a[la-1])
v = la-1
a.pop(v)
new = a+b
print(new)
