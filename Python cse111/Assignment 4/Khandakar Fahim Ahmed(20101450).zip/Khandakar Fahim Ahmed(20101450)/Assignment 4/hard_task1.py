while True:
    a=input()
    b=a.split(" ")
    if a=="STOP":
      break
    l=list(map(int,b))

    i = 0
    l1=[]

    while i < len(l) - 1:
        a = str(abs(l[i] - l[i + 1]))
        l1.append(a)
        i+=1
    l1=list(map(int,l1))

    count = 1
    l2 =[]
    while count <len(l):
        if count in l1:
            l2.append(count)
        count += 1

    if (len(l1) == len(l2)):
        print("UB Jumper")
    else:
        print("Not UB Jumper")
