l=input()
l1=""
l2=""
l3=""
for i in l:
    if i.islower():
        l1+=i
    if i.isupper():
        l2+=i
    if i.isnumeric():
        l3+=i
x=list(l1)
x.sort()
x1=''.join(x)
y=list(l2)
y.sort()
y1=''.join(y)
odd=""
even=""
for i in l3:
    x=int(i)
    if x%2==0:
        even+=i
    else:
        odd+=i
print(x1+y1+odd+even)
