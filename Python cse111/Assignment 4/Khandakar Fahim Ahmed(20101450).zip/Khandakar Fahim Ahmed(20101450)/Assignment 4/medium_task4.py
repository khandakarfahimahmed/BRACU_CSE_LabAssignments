a=int(input())
b=input()
sp=b.split(",")
list=[]
for i in range(a):
    list.append(i)

for i in range(a):
    list[i]=[]
x=0
tem=0
for i in list:
    x=tem
    while(x<len(sp)):
        i.append(sp[x])
        x=x+3
    tem=tem+1
print(list)
