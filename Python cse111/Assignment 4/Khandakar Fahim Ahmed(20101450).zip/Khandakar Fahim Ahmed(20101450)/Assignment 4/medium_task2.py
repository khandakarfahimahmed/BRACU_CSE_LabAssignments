q = int(input("Enter quantity: "))
l = []
for i in range(q):
    x = input("ENter number:")
    y = x.split(" ")
    z = list(map(int,y))
    l.append(z)
max = 0
tem = 0
for j in l:
    if sum(j)>max:
        max = sum(j)
        tem = j
print(max)
print(tem)
