a = []
for i in range(10):
    l = input("Enter input: ")

    if l in a:
        print("Enter a different number")
        break
    else:
        a.append(l)
