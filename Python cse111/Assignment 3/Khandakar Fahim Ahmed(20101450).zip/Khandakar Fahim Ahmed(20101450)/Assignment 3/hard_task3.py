a = input()
def string(s):
    word = s.split()
    b1 = ""
    b2 = ""
    b3 = ""
    b4 = ""
    chart1 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
              'v',
              'w', 'x', 'y', 'z']
    chart2 = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
              'V',
              'W', 'X', 'Y', 'Z']
    chart3 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    chart4 = ['_', '$', '@', '#', '&', '%', "^", '*', '?', '/', '!', '+', '-']
    for i in s:
        if i in chart1:
            b1 += i
        if i in chart2:
            b2 += i
        if i in chart3:
            b3 += i
        if i in chart4:
            b4 += i
    s1=""
    s2=""
    s3=""
    s4=""
    if b1 == "":
        s1 = "Lowercase character missing, "
    if b2 == "":
        s2 = "Uppercase character missing, "
    if b3 == "":
        s3 = "Digit missing, "
    if b4 == "":
        s4 = "Special character missing, "
    es=s1+s2+s3+s4
    if(es==""):
        print("OK")
    else:
        print(es[:-2])

string(a)
