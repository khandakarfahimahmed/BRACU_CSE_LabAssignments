inp = input("Enter input: ")
if " " in inp:
    inp = inp.replace(" ","")
backup = inp
inp = list(inp)
len = len(inp)
inp.reverse()
val = ""
for i in range(0,len):
    val = val+inp[i]
if val==backup:
    print("True")
else:
    print("False")
