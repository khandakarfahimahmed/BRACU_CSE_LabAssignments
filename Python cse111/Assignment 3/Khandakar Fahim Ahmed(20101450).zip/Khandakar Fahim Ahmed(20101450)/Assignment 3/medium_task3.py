a= input("Enter input: ")
l = len(a)
c=0
f = ""
for i in range(0,l):
    if a[i].isupper():
        f = f+a[i]
        c+=1
if c==2:
    x = f[0]
    x1 = f[1]
    j= a.index(x)
    p= a.index(x1)
    if a[j+1:p] != "":
        print(a[j+1:p])
    else:
        print("BLANK")
else:
    print("BLANK")
