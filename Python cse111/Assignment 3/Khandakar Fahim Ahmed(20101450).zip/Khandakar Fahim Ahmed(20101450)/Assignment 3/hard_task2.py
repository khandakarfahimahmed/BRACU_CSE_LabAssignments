x=input("Enter input: ")
def my_function(a):
    s = len(a) - 1
    p = s // 3
    c = 0
    flag = False
    while c <= p:
        if (a[:(p + 1 - c)]) == (a[(s - p + c):]):
            flag = True
            break;
        c += 1
    if flag == 1:
        if a[:(p + 1 - c)] in a[(p + 1 - c + 1):(s - p + c)]:
            print(a[:(p + 1 - c)])
        else:
            print("Not Palindrome Substring")
    else:
        print("Not Palindrome Substring")
my_function(x)
