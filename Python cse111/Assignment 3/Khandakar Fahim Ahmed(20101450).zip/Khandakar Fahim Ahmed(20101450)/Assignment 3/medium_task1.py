a  = input("Enter input: ")
u = 0
l = 0
for i in a:
    if i.isupper():
        u+=1
    elif i.islower():
        l+=1
    else:
        pass
if u<l or u==l:
    a = a.lower()
    print(a)
else:
    a = a.upper()
    print(a)
