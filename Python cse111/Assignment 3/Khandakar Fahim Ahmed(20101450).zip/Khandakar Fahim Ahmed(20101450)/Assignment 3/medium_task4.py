a = input("Enter input: ")
if "too good" in a:
    print(a.replace("too good","excellent"))
else:
    print(a)
