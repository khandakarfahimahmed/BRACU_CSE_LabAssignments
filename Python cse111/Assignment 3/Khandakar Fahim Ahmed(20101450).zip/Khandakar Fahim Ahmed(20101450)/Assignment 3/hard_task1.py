a=input("Enter input: ")
b=input("Enter input: ")
def string(x,y):
    s=""
    for i in x:
        if i in y:
            s += i
    for i in y:
        if i in x:
            s += i
    if (s != ""):
        print(s)
    else:
        print("Nothing in common.")
string(a,b)
