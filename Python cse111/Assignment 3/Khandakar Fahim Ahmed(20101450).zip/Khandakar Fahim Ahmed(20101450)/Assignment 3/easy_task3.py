a = input("Enter Input: ")
if len(a)<=4:
    print(a)
else:
    if "ful" in a:
        a = a + "ly"
        print(a)
    else:
        a = a + "ful"
        print(a)
