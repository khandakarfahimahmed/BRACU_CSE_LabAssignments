a = input("Enter input: ")
a = a.lower()
v = "aeiou"
s = ""
c = 0
for i in a:
    if i in v:
        c+=1
    if i not in v:
        s = s+i
print(s,c,sep="")
