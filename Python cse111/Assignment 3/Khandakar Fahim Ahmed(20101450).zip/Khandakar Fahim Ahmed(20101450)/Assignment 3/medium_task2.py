a = ["0","1","2","3","5","6","7","8","9"]
inp = input ("Enter your input: ")
try :
    inp = int(inp)
    del inp
    b= "NUMBER"
    print(b)
except:
    if inp.isalpha():
        inp = "Word"
        print(inp)
    else:
        inp = "MIXED"
        print(inp)
