x=int(input("Enter the name of days: "))
def val(n):
    years=n//365
    m=n%365
    month=m//30
    days=m%30
    print(years,"years,",month,"months and",days,"days")
val(x)
