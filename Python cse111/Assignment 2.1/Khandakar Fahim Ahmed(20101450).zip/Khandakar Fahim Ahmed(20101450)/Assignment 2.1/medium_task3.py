a = input("Enter name: ")
a = a.lower()
a = list(a)
b = len(a)
vowel = "aeiou"
vowel = list(vowel)
def check_vow(c=0,j=0,x=""):
    for  i in range(0,b):
        if a[i] in vowel:
            while j==0:
                print("Vowels: ",end="")
                j = 1
            x = x+","+a[i]
            c+=1
    print(x[1:],end="")
    if c==0:
        print("No vowels in the name")
    else:
        print(". Total number of vowels:",c)
check_vow()
