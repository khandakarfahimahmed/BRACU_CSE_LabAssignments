a=[]
def val():
    if 0 not in a:
        b = (a[0]/a[1])
        c = a[0]//a[1]
        d = b-c
    else:
        d=0
    return d
for i in range(0,2,+1):
    x = int(input("Enter numbers: "))
    a.append(x)
print(val())
