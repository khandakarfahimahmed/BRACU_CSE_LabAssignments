a=input("Enter email address: ")
b=input("Enter the new domain: ")
c=input("Enter the old domain: ")
def func(x,y,z):
    if y not in x:
        s=""
        for i in x:
            s+=i
            if(i=="@"):
                break

        print("Changed:",s+y,end="")
    else:
        print("Unchanged:",x)

func(a,b,c)
