from datetime import date
def yearCount(join_date):
	l=join_date.split("-")
	dif1 = date.today()
	dif2 = date(int(l[0]),int(l[1]),int(l[2]))
	dif = dif1-dif2
	l = dif.days/365
	return l
def salary(yos,sal):
	if yos<5:
		return sal*0.1
	elif yos<=10:
		return sal*0.1+5000
	else:
		return sal*.15+15000
def payment(*args):
	count = 0
	while count<len(args):
		i = len(args)
		newYear = yearCount(args[count+2])
		pay = salary(newYear,(args)[count+1])
		if count < i-3:
			print(args[count],":",pay,end=", ")
		else:
			print(args[count],":",pay,end=" ")
		count = count+3
payment("Alice", 20000, "2017-03-21", "Bob", 50000,"2007-05-10")
