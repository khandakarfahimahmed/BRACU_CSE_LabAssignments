food = input("These burgers(BBQ Chicken Cheese Burger,Beef Burger,Naga Drums) are available. Choose which one you want: ")
place  = input ("Enter your place: ")
food = food.lower()
place = place.lower()
def price(a,b,c = 0):
    if "mohakhali" == b:
        if "bbq chicken cheese burger" in a:
            c = 250+40+((250*8)/100)
        elif "beef burger" in a:
            c = 170+40+((170*8)/100)
        elif "naga drums" in a:
            c = 200+40+((200*8)/100)
    elif "" == b:
        if "bbq chicken cheese burger" in a:
            c = 250+40+((250*8)/100)
        elif "beef burger" in a:
            c = 170+40+((170*8)/100)
        elif "naga drums" in a:
            c = 200+40+((200*8)/100)
    else:
        if "bbq chicken cheese burger" in a:
            c = 250+60+((250*8)/100)
        elif "beef burger" in a:
            c = 170+60+((170*8)/100)
        elif "naga drums" in a:
            c = 200+60+((200*8)/100)
    return c
b = round(price(food,place), 1)
print(b)
