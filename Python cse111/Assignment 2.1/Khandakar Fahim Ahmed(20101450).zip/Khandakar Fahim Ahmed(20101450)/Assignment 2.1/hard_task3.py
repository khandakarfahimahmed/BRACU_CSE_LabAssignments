str = input("Enter input: ")
sz = len(str)
i = 0
while i<sz-1 :
   if i == 0:
      print(str[i].upper(),end='')
   elif str[i]=='i' and str[i-1]== ' ' and str[i+1] ==' ':
      print('I ',end='')
      i+=2
   elif str[i]=='.':
      print('. '+str[i+2].upper(),end='')
      i+=2
   elif str[i]=='!':
      print('! '+str[i+2].upper(),end='')
      i+=2
   elif str[i]=='?':
      print('? '+str[i+2].upper(),end='')
      i+=2
   else:
      print(str[i],end='')
   i+=1
print('.')
