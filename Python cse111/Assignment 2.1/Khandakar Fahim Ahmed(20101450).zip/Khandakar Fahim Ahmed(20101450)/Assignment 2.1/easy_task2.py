h = input("Enter your height in cm. :")
w = input("Enter your weight in kg. :")
try :
    h = float(h)
    w = float(w)
except:
    print("Invalid Input! (Avoid letters)")
    exit()
p = h/100
def BMI(a,b):
    b = (w/(p*p))
    return b

bmi = round(BMI(h,p), 1)
if bmi<18.5:
     print("Score is",bmi,end=".")
     print(" You are Underweight")
elif bmi<=24.9:
     print("Score is",bmi,end=".")
     print(" You are Normal")
elif bmi<=30:
     print("Score is",bmi,end=".")
     print(" You are Overweight")
else:
     print("Score is",bmi,end=".")
     print(" You are Obese")
