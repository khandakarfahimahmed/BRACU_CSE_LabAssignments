min = int(input("Enter minimum number: "))
max = int (input("Enter maximum number: "))
div = int(input("Enter divisor: "))
def val(a,b,c,sum):
    for a in range(a,b,c):
        sum = sum+a
    return sum
n = val(min,max,div,0)
print(n)
